$(function() {
    var socket = io.connect('http://localhost:3000')

    var username = $('#username');
    var message = $('#message');
    var username_send = $('#username_send');
    var message_send = $('#message_send');
    var chatroom = $('#chatroom');

    username_send.click(function() {
        console.log(username.val())
        socket.emit('change_username', {username : username.val()})
    })

    socket.on('new_message', (data) => {
        chatroom.append('<p class="message">' + data.username + ':' + data.message + '</p>')
    })
    
    message_send.click(function() {
        socket.emit('new_message', {message : message.val()})
    })

})